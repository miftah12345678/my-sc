<!--Viewport -->
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<h3>
	<div style="text-align: center;">
		<a href="../admin-dashboard/action-provider"><b>Kembali</b></a><br/>
	</div>
</h3>

<?php
session_start();
require_once ("../config.php");
require_once ("../lib/session_login_admin.php");

$cekarie = $conn->query("SELECT * FROM provider WHERE code = 'ARIEPULSA'");
$dataarie = mysqli_fetch_assoc($cekarie);
$action = 'layanan';

            $postdata = "api_key=".$dataarie['api_key']."&action=".$action."";
            $url = 'https://ariepulsa.com/api/pulsa';
                
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_HEADER, 0);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($curl, CURLOPT_TIMEOUT, 0);
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $postdata);
            curl_setopt($curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4); // tambahan curl ipv4
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, POST);
            curl_setopt($curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
	    	$response = curl_exec($curl);
            curl_close($curl);
			/*
			echo $response;
			*/
            $json_result = json_decode($response, true);

//Diambil dari parameter layanan / services
$indeks = 0;
while($indeks < count($json_result['data'])){
	$kategori = $json_result['data'][$indeks]['operator'];
	$kode = $json_result['data'][$indeks]['operator'];
	$tipe = $json_result['data'][$indeks]['tipe'];
	$indeks++;
	$check_kategori_pulsa = mysqli_query($conn, "SELECT * FROM kategori_layanan WHERE nama = '$kategori' AND tipe = '$tipe'");
	$data_services_pulsa = mysqli_fetch_assoc($check_kategori_pulsa);
	if(mysqli_num_rows($check_kategori_pulsa) > 0) {
		echo"<b>Kategori Sudah Ada</b> <br/>
		Kategori: $kategori <br/>
		Kode: $kode <br/>
		Tipe: $tipe <br/><br/>";
	} else {
		//Memasukan ke Database
		$insert = mysqli_query($conn, "INSERT INTO kategori_layanan (nama, kode, tipe) VALUES ('$kategori', '$kode', '$tipe') ");
		if($insert == TRUE){
			echo"<b>Kategori Disimpan</b> <br/>
			Kategori: $kategori <br/>
			Kode: $kode <br/>
			Tipe: $tipe <br/><br/>";
		} else{
			echo "<b>Kategori Gagal Disimpan</b> <br/>";
		}
	}
}

?>