<!--Viewport -->
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<h3>
    <div style="text-align: center;">
        <a href="../admin-dashboard/action-provider"><b>Kembali</b></a><br/>
    </div>
</h3>

<?php
session_start();
require_once ("../config.php");
require_once ("../lib/session_login_admin.php");

//DELL ALL KATEGORI
$delet_kategori_layanan = mysqli_query($conn, "DELETE FROM kategori_layanan");
if($delet_kategori_layanan == TRUE){
    echo"Kategori Dihapus <br/>";
}else{
    echo"Kategori Gagal Dihapus <br/>";
}

//DELL ALL KATEGORI SMM 2
$delet_kategori_layanan2 = mysqli_query($conn, "DELETE FROM kategori_layanan2");
if($delet_kategori_layanan2 == TRUE){
    echo"Kategori SMM 2 Dihapus <br/>";
}else{
    echo"Kategori SMM 2 Gagal Dihapus <br/>";
}

//DELL ALL KATEGORI SMM 3
$delet_kategori_layanan3 = mysqli_query($conn, "DELETE FROM kategori_layanan3");
if($delet_kategori_layanan3 == TRUE){
    echo"Kategori SMM 3 Dihapus <br/>";
}else{
    echo"Kategori SMM 3 Gagal Dihapus <br/>";
}

//DELL ALL PRODUK PULSA & PPOB
$delet_layanan_pulsa = mysqli_query($conn, "DELETE FROM layanan_pulsa");
if($delet_layanan_pulsa == TRUE){
	echo"Layanan PPOB & Pulsa Dihapus <br/>";
}else{
	echo"Layanan PPOB & Pulsa Gagal Dihapus <br/>";
}

//DELL ALL LAYANAN SOSMED
$delet_layanan_sosmed = mysqli_query($conn, "DELETE FROM layanan_sosmed");
if($delet_layanan_sosmed == TRUE){
    echo"Layanan Sosial Media Dihapus <br/>";
}else{
    echo"Layanan Sosial Media Gagal Dihapus <br/>";
}

//DELL ALL LAYANAN SOSMED 2
$delet_layanan_sosmed2 = mysqli_query($conn, "DELETE FROM layanan_sosmed2");
if($delet_layanan_sosmed2 == TRUE){
    echo"Layanan Sosial Media 2 Dihapus <br/>";
}else{
    echo"Layanan Sosial Media 2 Gagal Dihapus <br/>";
}

//DELL ALL LAYANAN SOSMED 3
$delet_layanan_sosmed3 = mysqli_query($conn, "DELETE FROM layanan_sosmed3");
if($delet_layanan_sosmed3 == TRUE){
    echo"Layanan Sosial Media 3 Dihapus <br/>";
}else{
    echo"Layanan Sosial Media 3 Gagal Dihapus <br/>";
}

//DELL ALL LAYANAN DIGITAL
$delet_layanan_digital = mysqli_query($conn, "DELETE FROM layanan_digital");
if($delet_layanan_digital == TRUE){
    echo"Layanan Digital Dihapus <br/>";
}else{
    echo"Layanan Digital Gagal Dihapus <br/>";
}

?>