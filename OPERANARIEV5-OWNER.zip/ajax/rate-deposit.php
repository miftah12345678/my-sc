<?php
//
//SC	:	KM Panel - SMM & PPOB
//Dev	:	BlackRose / Adi Gunawan, S.Kom., M.Kom.
//By	:	401XD Group Indonesia
//Email	:	mycoding@401xd.com / 401xdssh@gmail.com
//
//▪ http://401xd.com / http://mycoding.net
//▪ http://youtube.com/c/MyCodingXD
//▪ http://instagram.com/MyCodingXD
//▪ http://facebook.com/MyCodingXD
//
//Hak cipta 2017-2021
//Terakhir dikembangkan Februari 2021
//Dilarang menjual/membagikan script KM Panel. Serta mengubah/menghapus copyright ini!
//

session_start();
require_once '../config.php';

$pembayaran = $conn->real_escape_string($_POST['pembayaran']);
$nominal = $conn->real_escape_string($_POST['jumlah']);
$cek_rate = $conn->query("SELECT * FROM metode_depo WHERE id = '$pembayaran'");
$cek_hasil = $cek_rate->fetch_array();
$menghitung = $nominal * $cek_hasil['rate'];
echo $result;
?>