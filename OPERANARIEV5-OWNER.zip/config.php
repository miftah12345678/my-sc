<?php
	date_default_timezone_set('Asia/Jakarta');
	error_reporting(0);

	// status
	$maintenance = 0; //Ganti jadi 1 jika sedang MT
	if($maintenance == 1) {
		header("location: /offline"); //Ganti dengan landing page maintenance Anda
	}

	// database
	$config['db'] = array(
		'host' => 'localhost',
		'name' => 'opod5666_pulsaku1', //Ganti dengan nama database anda
		'username' => 'opod5666_pulsaku', //Ganti dengan username database anda
		'password' => '1710Romahi@@' //Ganti dengan password database anda
	);

	$conn = mysqli_connect($config['db']['host'], $config['db']['username'], $config['db']['password'], $config['db']['name']);
	if(!$conn) {
		die("Koneksi Gagal : ".mysqli_connect_error());
	}

	// Konfigurasi url domain
	$config['web'] = array(
		'url' => 'https://opotopup.com/', //diakhiri garis miring. ex: https://ariepulsa.com/
		'url_canonical' => 'https://opotopup.com' //tanpa garis miring. ex: https://ariepulsa.com
	);

	// date & time
	$date = date("Y-m-d");
	$time = date("H:i:s");

	// API google captcha v2 Checkbox: https://www.google.com/recaptcha/admin/create
	$config['captcha'] = array(
		'sitekey' => '6LeiwzMmAAAAALZ5SMvhmv_4iXaOGHuZRwCXeuT0',
		'secretkey' => '6LeiwzMmAAAAAHX9XV_xvlH0QCLo79EPu9uzHwvp'
	);

	// Email SMTP, Keamanan SSL, PORT 465
	// EMAIL MAILER INI DIREKOMENDASIKAN MENGGUNAKAN EMAIL SMTP HOSTING
	// INFORMASI PORT DAN HOST DIDAPAT SETELAH MEMBUAT EMAIL DI CPANEL
	$config['email'] = array(
		'enkripsi' => 'ssl', //ssl atau tls, direkomendasikan ssl
		'mailhost' => 'mail.opotopup.com', //host mail, ex: mail.kincaiseluler.my.id
		'mailport' => '465', //port email, ex: 465
		'mailusername' => 'verifikasi@opotopup.com', //email, ex: support@kincaiseluler.my.id
		'mailpassword' => 'Rahasiaku123' //password email
	);

	// versi
	$versi = '1';

	require("lib/function.php");

?>