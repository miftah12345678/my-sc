<?php
require("../config.php");
$cek_pesanan = $conn->query("SELECT * FROM pembelian_pulsa WHERE status IN ('Error') AND refund = '0'");

if (mysqli_num_rows($cek_pesanan) == 0) {
	die("Status Error/Partial Tidak Ditemukan");
} else {
	while($data_pesanan = mysqli_fetch_assoc($cek_pesanan)) {

		$harga = $data_pesanan['harga'];
		$profit = $data_pesanan['profit'];
		
		
			//NOTOFIKASI WHATAPPS GAGAL
			
			$cekwa = $conn->query("SELECT * FROM provider WHERE code = 'ARIESENDER'");
            $datawa = mysqli_fetch_assoc($cekwa);
            $license = $datawa['api_key'];
            $apiwa = $datawa['api_id'];

	        $phone = $data_pesanan['no_hp'];
            
            $message = (" Hai *".$data_pesanan['user']."*
Transaksi Kamu *GAGAL*
Waktu       : ".$data_pesanan['date']."/".$data_pesanan['time']."
Order ID        : *".$data_pesanan['oid']."*
Target          : *".$data_pesanan['target']."*
Layanan     : *".$data_pesanan['layanan']."*
DiRefund    : *Rp ".$data_pesanan['harga']."*
Status          : *".$data_pesanan['status']."*
Catatan: *Periksa Nomor Tujuan Anda Dan Coba Lagi Nanti*
            ");
            
            
    $url = 'https://wagw.ariesender.my.id/send-message';       
	$curl = curl_init();
	$gateway = [
		'api_key'    => $license,
		'sender'    => $apiwa,
        'number'     => $phone,
        'message'   => $message
			];

            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_HEADER, 0);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($curl, CURLOPT_TIMEOUT,30);
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $gateway);
            curl_setopt($curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4); //Hapus Jika Anda Menggunakan IPV6

	    	$response = curl_exec($curl);
            curl_close($curl);
			/*
			echo $response;
			*/

		$update_user = $conn->query("UPDATE users SET pemakaian_saldo = pemakaian_saldo - $harga WHERE user = '".$data_pesanan['user']."'");
		$update_user = $conn->query("UPDATE users SET saldo = saldo + $harga WHERE username = '".$data_pesanan['user']."'");
		$update_order = $conn->query("INSERT INTO history_saldo VALUES ('', '".$data_pesanan['user']."', 'Penambahan Saldo', '$harga', 'Pengembalian Dana. Order ID ".$data_pesanan['oid']."', '$date', '$time')");
		$update_order = $conn->query("UPDATE pembelian_pulsa SET refund = '1', profit = profit - $profit  WHERE oid = '".$data_pesanan['oid']."'");
		if ($update_order AND $update_user == TRUE) {
			echo "Dikembalikan: Rp $harga <br/>
			Order ID: ".$data_pesanan['oid']." <br/>
			Untuk: ".$data_pesanan['user']." <br/><br/>";
		} else {
			echo "Error database";
		}
	}
}

?>