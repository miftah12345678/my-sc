<?php
session_start();
require '../config.php';
require '../lib/session_user.php';
if (isset($_POST['pesan'])) {
	require '../lib/session_login.php';
	$post_kategori = $conn->real_escape_string(trim(filter($_POST['kategori'])));
	$post_layanan = $conn->real_escape_string(trim(filter($_POST['layanan'])));
	$post_jumlah = $conn->real_escape_string(trim(filter($_POST['jumlah'])));
	$post_target = $conn->real_escape_string(trim(filter($_POST['target'])));
	$post_comments = $_POST['comments'];

	$cek_layanan = $conn->query("SELECT * FROM layanan_sosmed3 WHERE service_id = '$post_layanan' AND status = 'Aktif'");
	$data_layanan = mysqli_fetch_assoc($cek_layanan);

	$cek_harga = $data_layanan['harga'] / 1000;
	$cek_profit = $data_layanan['profit'] / 1000;
	$hitung = count(explode(PHP_EOL, $post_comments));
	$replace = str_replace("\r\n",'\r\n', $post_comments);
	if (!empty($post_comments)) {
		$post_jumlah = $hitung;
	} else {
		$post_jumlah = $post_jumlah;
	}
	// $price = $rate*$post_quantity;
	if (!empty($post_comments)) {
		$harga = $cek_harga*$hitung;
		$profit = $cek_profit*$hitung;
	} else {
		$harga = $cek_harga*$post_jumlah;
		$profit = $cek_profit*$post_jumlah;
	}
	$order_id = acak_nomor(3).acak_nomor(4);
	$provider = $data_layanan['provider'];

	$cek_provider = $conn->query("SELECT * FROM provider WHERE code = '$provider'");
	$data_provider = mysqli_fetch_assoc($cek_provider);
	$action = 'pemesanan';

	$cek_pesanan = $conn->query("SELECT * FROM pembelian_sosmed WHERE user = '$sess_username' AND target = '$post_target' AND status = 'Pending' AND provider = '$provider'");
	$data_pesanan = mysqli_fetch_assoc($cek_pesanan);

	//Get Start Count
	if ($data_layanan['kategori'] == "Instagram Auto Likes [Per Minute] " OR "Instagram Likes" OR "Instagram Likes / Likes + Impressions" OR "Instagram Likes Indonesia") {
		$start_count = likes_count($post_target);
	} else if ($data_layanan['kategori'] == "Instagram Followers [Refill] [Guaranteed] [NonDrop" OR "Instagram Followers Indonesia" OR "Instagram Followers Indonesia [Bergaransi] Refill " OR "Instagram Followers Indonesia PAKET REAL " OR "Instagram Followers No Refill/Not Guaranteed") {
		$start_count = followers_count($post_target);
	} else if ($data_layanan['kategori'] == "Instagram TV" OR "Instagram Views") {
		$start_count = views_count($post_target);
	} else {
		$start_count = 0;
	}

	if (!$post_target || !$post_layanan || !$post_kategori) {
		$_SESSION['hasil'] = array('alert' => 'danger', 'judul' => 'Order Gagal', 'pesan' => 'Lengkapi Bidang Berikut:<br/> - Kategori <br /> - Layanan <br /> - Target');

	} else if (mysqli_num_rows($cek_layanan) == 0) {
		$_SESSION['hasil'] = array('alert' => 'danger', 'judul' => 'Order Gagal', 'pesan' => 'Layanan Tidak Tersedia');

	} else if (mysqli_num_rows($cek_provider) == 0) {
		$_SESSION['hasil'] = array('alert' => 'danger', 'judul' => 'Order Gagal', 'pesan' => 'Server Sedang Maintenance');

	} else if ($post_jumlah < $data_layanan['min']) {
		$_SESSION['hasil'] = array('alert' => 'danger', 'judul' => 'Order Gagal', 'pesan' => 'Jumlah Minimal Order '.number_format($data_layanan['min'],0,',','.').'.');

	} else if ($post_jumlah > $data_layanan['max']) {
		$_SESSION['hasil'] = array('alert' => 'danger', 'judul' => 'Order Gagal', 'pesan' => 'Jumlah Maksimal Order '.number_format($data_layanan['max'],0,',','.').'.');

	} else if ($data_user['saldo'] < $harga) {
		$_SESSION['hasil'] = array('alert' => 'danger', 'judul' => 'Order Gagal', 'pesan' => 'Saldo Tidak Mencukupi');

	} else if (mysqli_num_rows($cek_pesanan) == 1) {
		$_SESSION['hasil'] = array('alert' => 'danger', 'judul' => 'Order Gagal', 'pesan' => 'Orderan Sebelumnya di Layanan & Target yang Sama Masih Pending');

	//Post pesanan
	} else {

		if ($provider == "MANUAL") {
			$api_postdata = "";
		} else if ($provider == "ARIEPULSA") {
			if ($post_comments == false) {
				$postdata = "api_key=".$data_provider['api_key']."&action=$action&layanan=".$data_layanan['provider_id']."&target=$post_target&jumlah=$post_jumlah";
			} else if ($post_comments == true) {
				$postdata = "api_key=".$data_provider['api_key']."&action=$action&layanan=".$data_layanan['provider_id']."&target=$post_target&custom_comments=$post_comments";
			}
           $url = 'https://ariepulsa.com/api/sosial-media-3';
                
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_HEADER, 0);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($curl, CURLOPT_TIMEOUT, 0);
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $postdata);
            curl_setopt($curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4); // tambahan curl ipv4
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, POST);
            curl_setopt($curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
	    	$response = curl_exec($curl);
            curl_close($curl);
			/*
			echo $response;
			*/
            $json_result = json_decode($response, true);

		} else {
			die("System Error!");
		}
		if ($provider == "ARIEPULSA" AND $json_result['status'] == false) {
			$_SESSION['hasil'] = array('alert' => 'danger', 'judul' => 'Order Gagal', 'pesan' => ''.$json_result['data']['pesan']);
		} else {
			if ($provider == "ARIEPULSA") {
				$provider_oid = $json_result['data']['id'];
			}

			if ($conn->query("INSERT INTO pembelian_sosmed VALUES ('','$order_id', '$provider_oid', '$sess_username', '".$data_layanan['layanan']."', '$post_target', '$post_jumlah', '0', '$start_count', '$harga', '$profit', 'Pending', '$date', '$time', '$provider', 'Website', '0')") == true) {
				$conn->query("UPDATE users SET saldo = saldo-$harga, pemakaian_saldo = pemakaian_saldo+$harga WHERE username = '$sess_username'");
				$conn->query("INSERT INTO history_saldo VALUES ('', '$sess_username', 'Pengurangan Saldo', '$harga', 'Order ID $order_id Layanan SMM', '$date', '$time')");	   				
				$jumlah = number_format($post_jumlah,0,',','.');
				$harga2 = number_format($harga,0,',','.');
				$_SESSION['hasil'] = array(
					'alert' => 'success',
					'judul' => 'Order Berhasil',
					'pesan' => '<br />
					-<b>Order ID: </b> '.$order_id.'<br />
					-<b>Layanan: </b> '.$data_layanan['layanan'].'<br />
					-<b>Target: </b> '.$post_target.'<br />
					-<b>Start: </b> '.$start_count.'<br />
					-<b>Jumlah: </b> '.$jumlah.'<br />
					-<b>Harga: </b> Rp '.$harga2.'');
			} else {
				$_SESSION['hasil'] = array('alert' => 'danger', 'judul' => 'Order Gagal', 'pesan' => 'Layanan Maintenance. Coba Lagi 1 Jam Berikutnya.');
			}
		}
	}
}

require("../lib/header.php");
?>

<!--Title-->
<title>SOSIAL MEDIA 3</title>
<meta name="description" content="Platform Layanan Digital All in One, Berkualitas, Cepat & Aman. Menyediakan Produk & Layanan Pemasaran Sosial Media, Payment Point Online Bank, Layanan Pembayaran Elektronik, Optimalisasi Toko Online, Voucher Game dan Produk Digital."/>

<div class="row">
	<div class="col-md-7">
		<div class="card">
			<div class="card-body">
				<h4 class="m-t-0 text-uppercase text-center header-title"><i class="mdi mdi-instagram mr1 text-primary"></i><b> SOSIAL MEDIA 3</b></h4><hr>
					
				<form class="form-horizontal" method="POST">
					<input type="hidden" name="csrf_token" value="<?php echo $config['csrf_token'] ?>">   										    
					<div class="form-group">
						<label class="col-md-12 control-label">Kategori *</label>
						<div class="col-md-12">
							<select class="form-control" id="kategori" name="kategori">
								<option value="">Pilih Salah Satu</option>
								<?php
								$cek_kategori = $conn->query("SELECT * FROM kategori_layanan3 WHERE tipe = 'Sosial Media' ORDER BY nama ASC");
								while ($data_kategori = $cek_kategori->fetch_assoc()) {
									?>
									<option value="<?php echo $data_kategori['kode']; ?>"><?php echo $data_kategori['nama']; ?></option>
								<?php } ?>
							</select>
						</div>
					</div>

					<div class="form-group">
						<label class="col-md-12 control-label">Layanan *</label>
						<div class="col-md-12">
							<select class="form-control" name="layanan" id="layanan">
								<option value="0">Pilih Kategori</option>
							</select>
						</div>
					</div>

					<div id="catatan">
					</div>

					<div class="form-group">
						<label class="col-md-12 control-label">Target *</label>
						<div class="col-md-12">
							<input type="text" name="target" class="form-control" placeholder="Username / Link">
						</div>
					</div>

					<div id="show1">
						<div class="form-row">

							<div class="form-group col-md-6">
								<label class="col-md-12 col-form-label">Jumlah *</label>
								<div class="col-md-12">
									<input type="number" name="jumlah" class="form-control" placeholder="Jumlah" onkeyup="get_total(this.value).value;">
								</div>
							</div>
							<input type="hidden" id="rate" value="0">
							<div class="form-group col-md-6">
								<label class="col-md-12 col-form-label">Total</label>
								<div class="col-md-12">
									<div class="input-group">
										<div class="input-group-prepend">
											<span class="input-group-text">Rp. </span>
										</div>
										<input type="number" class="form-control" id="total" readonly>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div id="show2" style="display: none;">
						<div class="form-row">
							<div class="form-group col-md-6">
								<label class="col-md-12 col-form-label">Komentar</label>
								<div class="col-md-12">
									<textarea class="form-control" name="comments" id="comments" placeholder="Pisahkan setiap baris komentar dengan enter"></textarea>
								</div>
							</div>
							<input type="hidden" id="rate" value="0">
							<div class="form-group col-md-6">
								<label class="col-form-label">Total Harga</label>
								<div class="col-md-12">
									<div class="input-group">
										<div class="input-group-prepend">
											<span class="input-group-text">Rp. </span>
										</div>
										<input type="number" class="form-control" id="totalxx" readonly>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="col-md-12"> <button type="submit" class="pull-right btn btn-block btn--md btn-primary waves-effect w-md waves-light" name="pesan"><i class="mdi mdi-cart"></i>Order</button> </div>

				</form>

				<div style="text-align: center;">
					<br/>Dengan melakukan order, Anda telah memahami dan menyetujui <a href="#informasiorder"><b>Syarat & Ketentuan</b></a>, serta mengikuti <a href="#informasiorder"><b>Cara Melakukan Order</b></a> sesuai panduan.
				</div>

			</div>
		</div> 
	</div> 
	<!-- end col -->

	<!-- INFORMASI ORDER -->
	<div class="col-md-5" id="informasiorder">
		<div class="card">
			<div class="card-body">

				<center><h4 class="m-t-0 text-uppercase header-title"><i aria-hidden="true" class="fa fa-info-circle"></i><b> Informasi Order</h4></b>
					Gunakan koneksi internet yang stabil agar daftar layanan sinkron dengan kategori yang dipilih.<hr>
				</center>

				<!--KETENTUAN-->
				<div class="table-responsive">
					<center><i aria-hidden="true" class="fa fa-check-circle"></i><b> Syarat & Ketentuan</b></center>
					<ol class="list-p">
						<li>Mengikuti cara order di bawah.</li>
						<li>Memahami & mengikuti <a href="#catatan"><b><u>Deskripsi</u></b></a> dibawah pilihan layanan.</li>
						<li>Target atau tujuan sesuai <b><a href="/halaman/target-pesanan" target="_blank">Contoh Target Pesanan</a></b>.</li>
						<li>Kesalahan input dan order pending atau processing tidak dapat di cancel atau refund.</li>
						<li>Order baru untuk layanan & target yang sama, tunggu status order sebelumnya <span class="badge badge-success"><b>Success</b></span>.</li>
						<li>Memahami & mengikuti <b><a href="/halaman/status-order" target="_blank">Informasi Status Order</a></b>.</li>
						<li>Memahami & mengikuti <b><a href="/halaman/ketentuan-layanan" target="_blank">Ketentuan Layanan</a></b> & <b><a href="/halaman/pertanyaan-umum" target="_blank">FAQs</a></b>.</li>
					</ol>
				</div>

				<!--CARA-->
				<div class="table-responsive">
					<center><i aria-hidden="true" class="fa fa-check-circle"></i><b> Cara Melakukan Order</b></center>
					<ol class="list-p">
						<li>Pilih salah satu kategori & layanan.</li>
						<li>Masukkan username atau url pada target (<b><a href="/halaman/target-pesanan" target="_blank">Lihat Contoh</a></b>).</li>
						<li>Masukkan jumlah pemesanan</li>
						<li>Klik <span class="badge badge-primary"><b>Order</b></span> untuk memesan.</li>
					</ol>
				</div>

			</div>
		</div>
	</div>
	<!-- INFORMASI ORDER -->
</div>

<script type="text/javascript">
	$(document).ready(function() {
		$("#kategori").change(function() {
			var kategori = $("#kategori").val();
			$.ajax({
				url: '<?php echo $config['web']['url']; ?>ajax/layanan_sosmed_ariepulsa_3.php',
				data: 'kategori=' + kategori,
				type: 'POST',
				dataType: 'html',
				success: function(msg) {
					$("#layanan").html(msg);
				}
			});
		});
		$("#layanan").change(function() {
			var layanan = $("#layanan").val();
			$.ajax({
				url: '<?php echo $config['web']['url']; ?>ajax/catatan_sosmed_3.php',
				data: 'layanan=' + layanan,
				type: 'POST',
				dataType: 'html',
				success: function(msg) {
					$("#catatan").html(msg);
				}
			});
			$.ajax({
				url: '<?php echo $config['web']['url']; ?>ajax/rate_sosmed_3.php',
				data: 'layanan=' + layanan,
				type: 'POST',
				dataType: 'html',
				success: function(msg) {
					$("#rate").val(msg);
				}
			});
		});
	});
	document.getElementById("show1").style.display = "none";
	$("#layanan").change(function() {
		var selectedCountry = $("#layanan option:selected").text();
		if (selectedCountry.indexOf('Komen') !== -1 || selectedCountry.indexOf('komen') !== -1 || selectedCountry.indexOf('comment') !== -1 || selectedCountry.indexOf('Comment') !== -1) {
			document.getElementById("show1").style.display = "none";
			document.getElementById("show2").style.display = "block";
		} else {
			document.getElementById("show1").style.display = "block";
			document.getElementById("show2").style.display = "none";
		}
	});
	$(document).ready(function(){
		$("#comments").on("keypress", function(a){
			if(a.which == 13) {
				var baris = $("#comments").val().split(/\r|\r\n|\n/).length;
				var rates = $("#rate").val();
				var calc = eval(baris)*rates;
				console.log(calc)
				$('#totalxx').val(calc);
			}
		});

	});
	function get_total(quantity) {
		var rate = $("#rate").val();
		var result = eval(quantity) * rate;
		$('#total').val(result);
	}
</script>						
<?php
require ("../lib/footer.php");
?>